package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class AboutActivity : AppCompatActivity() {
    lateinit var button1:Button
    lateinit var button2:Button
    lateinit var button3:Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about)
        button1=findViewById(R.id.button1)
        button1.setOnClickListener {
            val intent= Intent(this,AppUpdateActivity::class.java)
            startActivity(intent)
        }

        button2=findViewById(R.id.button2)
        button2.setOnClickListener {
            val intent=Intent(this,DataPolicyActivity::class.java)
            startActivity(intent)
        }

        button3=findViewById(R.id.button3)
        button3.setOnClickListener {
            val intent=Intent(this,TermsToUseActivity::class.java)
            startActivity(intent)
        }
    }
}