package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast

class ProfileActivity : AppCompatActivity() {
    lateinit var btn:Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        btn=findViewById(R.id.btn)
        btn.setOnClickListener {
            Toast.makeText(this,"Changes Saved Successfully",Toast.LENGTH_LONG).show()
        }
    }
}