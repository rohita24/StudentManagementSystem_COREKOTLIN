package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Switch
import android.widget.Toast

class AppUpdateActivity : AppCompatActivity() {
    lateinit var switch1:Switch
    lateinit var switch2:Switch
    lateinit var switch3:Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_app_update)

        switch1=findViewById(R.id.switch1)
        switch1?.setOnCheckedChangeListener{_, isChecked ->
            Toast.makeText(this,"Your App will Update automatically", Toast.LENGTH_LONG).show()

        }

        switch2=findViewById(R.id.switch2)
        switch2?.setOnCheckedChangeListener{_, isChecked ->
            Toast.makeText(this,"Allows App to Nofify update available", Toast.LENGTH_LONG).show()
        }

        switch3=findViewById(R.id.switch3)
        switch3?.setOnCheckedChangeListener{_, isChecked ->
            Toast.makeText(this,"Allows App to Notify update install", Toast.LENGTH_LONG).show()

        }
    }
}