package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.PersistableBundle
import android.view.Menu
import android.view.MenuItem
import android.widget.ImageButton
import android.widget.Switch
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    lateinit var profile: ImageButton
    lateinit var attendence: ImageButton
    lateinit var exam: ImageButton
    lateinit var result: ImageButton
    lateinit var staff: ImageButton
    lateinit var calendar: ImageButton
    lateinit var assignment: ImageButton
    lateinit var event: ImageButton
    lateinit var notice: ImageButton
    lateinit var timetable: ImageButton
    lateinit var fees: ImageButton
    lateinit var logout: ImageButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        profile = findViewById(R.id.imagebutton1)
        profile.setOnClickListener {
            val intent = Intent(this, ProfileActivity::class.java)
            startActivity(intent)
        }
        attendence = findViewById(R.id.imagebutton2)
        attendence.setOnClickListener {
            val intent = Intent(this, AttendenceActivity::class.java)
            startActivity(intent)
        }
        exam = findViewById(R.id.imagebutton3)
        exam.setOnClickListener {
            val intent = Intent(this, ExamActivity::class.java)
            startActivity(intent)
        }
        result = findViewById(R.id.imagebutton4)
        result.setOnClickListener {
            val intent = Intent(this, ResultActivity::class.java)
            startActivity(intent)
        }
        staff = findViewById(R.id.imagebutton5)
        staff.setOnClickListener {
            val intent = Intent(this, StaffActivity::class.java)
            startActivity(intent)
        }
        calendar = findViewById(R.id.imagebutton6)
        calendar.setOnClickListener {
            val intent = Intent(this, CalendarActivity::class.java)
            startActivity(intent)
        }
        assignment = findViewById(R.id.imagebutton7)
        assignment.setOnClickListener {
            val intent = Intent(this, AssignmentActivity::class.java)
            startActivity(intent)
        }
        event = findViewById(R.id.imagebutton8)
        event.setOnClickListener {
            val intent = Intent(this, EventActivity::class.java)
            startActivity(intent)
        }
        notice = findViewById(R.id.imagebutton9)
        notice.setOnClickListener {
            val intent = Intent(this, NoticeActivity::class.java)
            startActivity(intent)
        }
        timetable = findViewById(R.id.imagebutton10)
        timetable.setOnClickListener {
            val intent = Intent(this, TimetableActivity::class.java)
            startActivity(intent)
        }
        fees = findViewById(R.id.imagebutton11)
        fees.setOnClickListener {
            val intent = Intent(this, FeesActivity::class.java)
            startActivity(intent)
        }
        logout = findViewById(R.id.imagebutton12)
        logout.setOnClickListener {
            val intent = Intent(this, LogoutActivity::class.java)
            startActivity(intent)
        }

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.studentmenu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        if (id == R.id.about) {
            val intent = Intent(this, AboutActivity::class.java)
            startActivity(intent)
            return true
        }

        if (id == R.id.settings) {
            val intent = Intent(this, SettingsActivity::class.java)
            startActivity(intent)
            return true
        }
        if (id == R.id.english)
        {
           Toast.makeText(this,"English is Selected",Toast.LENGTH_LONG).show()
            return true
        }
        if (id == R.id.tamil)
        {
            Toast.makeText(this,"Tamil is Selected",Toast.LENGTH_LONG).show()
            return true
        }
        if (id == R.id.telugu)
        {
            Toast.makeText(this,"Telugu is Selected",Toast.LENGTH_LONG).show()
            return true
        }

        if (id == R.id.hindi)
        {
            Toast.makeText(this,"Hindi is Selected",Toast.LENGTH_LONG).show()
            return true
        }

        if (id == R.id.malayalam)
        {
            Toast.makeText(this,"Malayalam is Selected",Toast.LENGTH_LONG).show()
            return true
        }

        if (id == R.id.kannada)
        {
            Toast.makeText(this,"Kannada is Selected",Toast.LENGTH_LONG).show()
            return true
        }
        if (id == R.id.marati)
        {
            Toast.makeText(this,"Marati is Selected",Toast.LENGTH_LONG).show()
            return true
        }
        if(id==R.id.help)
        {
            val intent=Intent(this,HelpActivity::class.java)
            startActivity(intent)
            return true
        }

        return super.onOptionsItemSelected(item)
    }
}