package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*

class SettingsActivity : AppCompatActivity() {
    lateinit var switch1:Switch
    lateinit var switch2:Switch
    lateinit var switch3:Switch
    lateinit var switch4:Switch
    var items= arrayOf("Size","Small","Medium","Large")
    var spinner: Spinner?=null
    var textView2:TextView?=null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        spinner=findViewById(R.id.spinner)
        textView2=findViewById(R.id.textView2)

        val adapter = ArrayAdapter (this,android.R.layout.simple_spinner_item,items)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner!!.setAdapter(adapter)
        spinner!!.onItemSelectedListener=object : AdapterView.OnItemSelectedListener {

            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                Toast.makeText(this@SettingsActivity,items[position], Toast.LENGTH_LONG).show()
            }
            override fun onNothingSelected(p0: AdapterView<*>?) {
                TODO("Not yet implemented")
            }
        }

        switch1=findViewById(R.id.switch1)
        switch1?.setOnCheckedChangeListener{_, isChecked ->
            Toast.makeText(this,"Your Account is Private",Toast.LENGTH_LONG).show()
        }

        switch2=findViewById(R.id.switch2)
        switch2?.setOnCheckedChangeListener{_, isChecked ->
            Toast.makeText(this,"Vibration Mode On",Toast.LENGTH_LONG).show()

        }

        switch3=findViewById(R.id.switch3)
        switch3?.setOnCheckedChangeListener{_, isChecked ->
            Toast.makeText(this,"Notification will be shown",Toast.LENGTH_LONG).show()

        }

        switch4=findViewById(R.id.switch4)
        switch4?.setOnCheckedChangeListener{_, isChecked ->
            Toast.makeText(this,"Notification Sound will be allowed",Toast.LENGTH_LONG).show()

        }

    }
}