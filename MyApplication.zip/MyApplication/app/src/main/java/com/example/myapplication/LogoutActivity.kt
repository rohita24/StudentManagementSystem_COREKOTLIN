package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class LogoutActivity : AppCompatActivity() {
    lateinit var etUserName: EditText
    lateinit var etPassword: EditText
    lateinit var btn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_logout)

        etUserName = findViewById(R.id.etUserName)
        etPassword = findViewById(R.id.etPassword)
        btn = findViewById(R.id.btnLogin)

        btn.setOnClickListener {
            var username: String = etUserName.text.toString()
            var password: String = etPassword.text.toString()
            if (username.equals("Rohita") and password.equals("2452")) {
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
            } else {
                Toast.makeText(this, "INVALID Username/Password", Toast.LENGTH_LONG).show()
            }
        }
    }
}